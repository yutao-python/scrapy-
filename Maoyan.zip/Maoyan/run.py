from scrapy import cmdline

cmdline.execute('scrapy crawl maoyan2 -o maoyan.json'.split())