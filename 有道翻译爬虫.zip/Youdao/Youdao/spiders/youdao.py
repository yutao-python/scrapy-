# -*- coding: utf-8 -*-
import scrapy
import time
import random
from hashlib import md5
import json
from ..items import YoudaoItem

class YoudaoSpider(scrapy.Spider):
    name = 'youdao'
    allowed_domains = ['fanyi.youdao.com']
    post_url = 'http://fanyi.youdao.com/translate_o?smartresult=dict&smartresult=rule'
    word = input('请输入要翻译的单词:')

    def start_requests(self):
        """把post_url和formdata一起交给调度器入队列"""
        ts, salt, sign = self.get_ts_salt_sign()
        formdata = {
            "i": self.word,
            "from": "AUTO",
            "to": "AUTO",
            "smartresult": "dict",
            "client": "fanyideskweb",
            "salt": salt,
            "sign": sign,
            "ts": ts,
            "bv": "75a84f6fbcebd913f0a4e81b6ee54608",
            "doctype": "json",
            "version": "2.1",
            "keyfrom": "fanyi.web",
            "action": "FY_BY_REALTlME",
        }

        yield scrapy.FormRequest(
            url = self.post_url,
            formdata = formdata,
            callback = self.parse
        )

    def get_ts_salt_sign(self):
        ts = str(int(time.time()*1000))
        salt = ts + str(random.randint(0,9))
        # sign是md5加密后的结果,word为翻译的单词
        string = "fanyideskweb" + self.word + salt + "n%A-rKaT5fb[Gy?;N5@Tj"
        s = md5()
        s.update(string.encode())
        sign = s.hexdigest()

        return ts,salt,sign

    def parse(self, response):
        html = json.loads(response.text)
        item = YoudaoItem()
        item['result'] = html['translateResult'][0][0]['tgt']

        yield item








