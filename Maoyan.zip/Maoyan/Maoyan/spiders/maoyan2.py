# -*- coding: utf-8 -*-
import scrapy
# 导入items.py中的类,为了给定义的数据结构赋值
from ..items import MaoyanItem

class MaoyanSpider(scrapy.Spider):
    name = 'maoyan2'
    allowed_domains = ['maoyan.com']
    url = 'https://maoyan.com/board/4?offset={}'

    # 重写start_requests()方法
    def start_requests(self):
        for offset in range(0,91,10):
            url = self.url.format(offset)
            # 交给调度器入队列
            yield scrapy.Request(url=url,callback=self.parse_html)

    def parse_html(self, response):
        dd_list = response.xpath('//dl[@class="board-wrapper"]/dd')
        # 创建item对象
        item = MaoyanItem()
        for dd in dd_list:
            # 1. xpath          : [<selector xpath='' data='One'>,<selector xpath='' data='Two'>]
            # 2. extract()      : ['One','Two']
            # 3. extract_first(): 'One'
            # 4. get()          : 'One'
            item['name'] = dd.xpath('./a/@title').get()
            item['star'] = dd.xpath('.//p[@class="star"]/text()').get()
            item['time'] = dd.xpath('.//p[@class="releasetime"]/text()').get()

            # 交给管道文件pipelinses.py处理
            yield item

















